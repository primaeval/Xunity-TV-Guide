import time
import os
import xbmc
import xbmcgui
import xbmcaddon

databasePath = xbmc.translatePath('special://userdata/addon_data/script.nohatsguide')
d = xbmcgui.Dialog()

			
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "categories.ini" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "addons.ini" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "addons.ini.local" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "guide.xml" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "category_count.ini" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "channel_id_title.ini" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "channels.ini" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "custom_stream_urls_autosave.ini" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "custom_stream_url_autosave_ini_last" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "tvdb.pickle" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
						
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "master.xml" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "settings.xml" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "source.db" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
			
			

d = xbmcgui.Dialog()			
d.ok('Xunity TV Guide', 'Please restart for ','the changes to take effect','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
