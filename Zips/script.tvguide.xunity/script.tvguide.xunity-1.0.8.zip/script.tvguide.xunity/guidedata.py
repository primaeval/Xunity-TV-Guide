import time
import os
import xbmc
import xbmcgui
import xbmcaddon

databasePath = xbmc.translatePath('special://profile/addon_data/script.tvguide.xunity')
d = xbmcgui.Dialog()

			
for root, dirs, files in os.walk(databasePath,topdown=True):
	dirs[:] = [d for d in dirs]
	for name in files:
		if "guide.xml" in name:
			try:
				os.remove(os.path.join(root,name))
			except: 
				d = xbmcgui.Dialog()
				d.ok('Xunity TV Guide', 'Error Removing ' + str(name),'','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
				pass
		else:
			continue
			
d = xbmcgui.Dialog()			
d.ok('Xunity TV Guide', 'Please restart for ','the changes to take effect','[COLOR steelblue]Thank you for using Xunity TV Guide[/COLOR]')
