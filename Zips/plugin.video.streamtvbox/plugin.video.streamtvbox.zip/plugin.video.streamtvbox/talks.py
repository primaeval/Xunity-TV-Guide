import os,xbmc,re

addon_path = xbmc.translatePath(os.path.join('special://home/addons', 'script.icechannel.extn.xunitytalk'))
repo_path = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xunitytalk'))
repoxml = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xunitytalk','addon.xml'))
addonxml=xbmc.translatePath(os.path.join('special://home/addons', 'script.icechannel.extn.xunitytalk','addon.xml'))


WRITEME='''<?xml version="1.0" encoding="UTF-8"?>
        <addon id="script.icechannel.extn.xunitytalk" version="0.0.1" name=".[COLOR blue]X[/COLOR]unity Talk iStream Extensions" provider-name="[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk">
            <requires>
                <import addon="xbmc.python" version="2.1.0"/>
            </requires>
                <extension library="default.py" point="xbmc.service" />
                        <summary lang="en">iStream Extensions by xunitytalk.com</summary>
            <extension point="xbmc.python.module" library="lib" />
            <extension point="xbmc.addon.metadata">
                        <description lang="en">iStream Extensions by Xunity Talk Movies Tv Shows Kids Live</description>
                        <!--<provides>video</provides>-->
                        <platform></platform>
                        <language></language>
                        <license></license>
                        <forum></forum>
                        <website></website>
                        <source></source>
                        <email></email>
            </extension>
          <extension point="xbmc.service" library="service.py" start="login" />
        </addon>'''




if os.path.exists(addonxml) == False:

    if os.path.exists(addon_path) == False:
        os.makedirs(addon_path)


        f = open(addonxml, mode='w')
        f.write(WRITEME)
        f.close()

        xbmc.executebuiltin('UpdateLocalAddons') 
        xbmc.executebuiltin("UpdateAddonRepos")


WRITEREPO='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="repository.xunitytalk" name=".[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk Repository" version="1.1.1" provider-name=".[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk">
	<extension point="xbmc.addon.repository" name="Mikey1234 Addon Repository">
		<info compressed="false">http://xtyrepo.me/xunitytalk/addons/addons.xml</info>
		<checksum>http://xtyrepo.me/xunitytalk/addons/addons.xml.md5</checksum>
		<datadir zip="true">http://xtyrepo.me/xunitytalk/addons</datadir>
	</extension>
	<extension point="xbmc.addon.metadata">
		<summary>The Best Third Party Addons for XBMC, .[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk</summary>
		<description>The Best Third Party Addons for XBMC, .[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk</description>
		<platform>all</platform>
	</extension>
</addon>
'''

if os.path.exists(repoxml) == False:

    if os.path.exists(repo_path) == False:
        os.makedirs(repo_path)


        f = open(addonxml, mode='w')
        f.write(WRITEREPO)
        f.close()

        xbmc.executebuiltin('UpdateLocalAddons') 
        xbmc.executebuiltin("UpdateAddonRepos")



xbmc_version =  re.search('^(\d+)', xbmc.getInfoLabel( "System.BuildVersion" ))
if xbmc_version:
    xbmc_version = int(xbmc_version.group(1))
else:
    xbmc_version = 1    
if xbmc_version >= 16.9:
        dependencies = ['repository.xunitytalk','script.icechannel.extn.xunitytalk']            
        import glob
        for THEPLUGIN in dependencies:
            xbmc.log(str(THEPLUGIN))
            query = '{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":true}, "id":1}' % (THEPLUGIN)
         
            xbmc.executeJSONRPC(query)
    
        xbmc.executebuiltin('UpdateLocalAddons') 
        xbmc.executebuiltin("UpdateAddonRepos")
