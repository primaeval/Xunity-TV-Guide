import xbmc,xbmcaddon

import time

addon         = 'plugin.video.stvbguide'
ADDONID       = addon


def SetSetting(param, value):
    value = str(value)
    if GetSetting(param) == value:
        return
    xbmcaddon.Addon(ADDONID).setSetting(param, value)

def GetSetting(param):
    return xbmcaddon.Addon(ADDONID).getSetting(param)



SetSetting('xmltv.interval', '0')
time.sleep(2)
xbmc.executebuiltin('ActivateWindow(videos,plugin://plugin.video.stvbguide,return)')


