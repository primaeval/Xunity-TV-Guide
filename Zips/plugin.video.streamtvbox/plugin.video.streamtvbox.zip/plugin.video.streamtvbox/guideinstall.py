import os,xbmc


addonxml=xbmc.translatePath(os.path.join('special://home/addons', 'plugin.video.stvbguide','addon.xml'))
addon_path = xbmc.translatePath(os.path.join('special://home/addons', 'plugin.video.stvbguide'))



WRITEME='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="plugin.video.stvbguide" name="StreamTvBox TV Guide" version="0.0.1" provider-name="Rolica, XunityTalk">
	<requires>
		<import addon="xbmc.python" version="2.1.0"/>
		<import addon="script.module.simplejson" version="0.0.1"/>
	</requires>
	<extension point="xbmc.python.script" library="addon.py">
            <provides>video</provides>
    </extension>
    <extension point="xbmc.service" library="service.py" start="login"/>
	<extension point="xbmc.addon.metadata">
		<summary lang="en">StreamTvBoxTV Guide allows you to combine your StreamTVBox service with a fully working EPG</summary>
		<description lang="en">StreamTvBoxTV Guide allows you to combine your StreamTVBox service with a fully working EPG.[CR][CR][COLOR hotpink]You need to have an active subscription to[/COLOR] [COLOR dodgerblue]StreamTVBox[/COLOR] [COLOR hotpink]and have their plugin installed already.[/COLOR]</description>
		<disclaimer lang="en">StreamTvBoxTV Guide is based on the original TV Guide addon by twinther.</disclaimer>
		<language></language>
		<platform>all</platform>
		<license>GPLv2</license>
		<forum>http://rolica.co.uk/forum/</forum>
		<source>https://github.com/bluezed/FTV-Guide-Repo</source>
        <website></website>
		<email></email>
	</extension>
</addon>'''

if os.path.exists(addon_path) == False:
        os.makedirs(addon_path)

f = open(addonxml, mode='w')
f.write(WRITEME)
f.close()

xbmc.executebuiltin('UpdateLocalAddons') 
xbmc.executebuiltin("UpdateAddonRepos")


