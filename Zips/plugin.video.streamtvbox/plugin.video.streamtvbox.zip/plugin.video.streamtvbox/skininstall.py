import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import extract
import downloader



def setSetting(setting, value):
    setting = '"%s"' % setting

    if isinstance(value, list):
        text = ''
        for item in value:
            text += '"%s",' % str(item)

        text  = text[:-1]
        text  = '[%s]' % text
        value = text

    elif not isinstance(value, int):
        value = '"%s"' % value

    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (setting, value)
    xbmc.executeJSONRPC(query)

def getSetting(setting):
  
        import json
        setting = '"%s"' % setting
 
        query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
        response = xbmc.executeJSONRPC(query)

        response = json.loads(response)                

        if response.has_key('result'):
            if response['result'].has_key('value'):
                return response ['result']['value']




def install():
    addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))

    packages = xbmc.translatePath(os.path.join('special://home/addons','packages'))

    SKINURL = 'http://xtyrepo.me/xunitytalk/addons/skin.streamtvbox/skin.streamtvbox-0.0.1.zip'



    dp = xbmcgui.DialogProgress()
    dp.create("StreamTvBox Skin","Downloading ",'StreamTvBox Skin', 'Please Wait')

    downloader.download(SKINURL, os.path.join(packages,'skin.streamtvbox.zip'), dp)
    dp.update(0,'StreamTvBox Skin', "Extracting Zip Please Wait")
    extract.all(os.path.join(packages,'skin.streamtvbox.zip'),addonfolder,dp)



    xbmc.executebuiltin('UpdateLocalAddons') 
    xbmc.executebuiltin("UpdateAddonRepos")
    dialog = xbmcgui.Dialog()
    setSetting('lookandfeel.skin', 'skin.streamtvbox')


if __name__ == '__main__': 
        install() #silent
if __name__ == 'skininstall':
        install() #silent
